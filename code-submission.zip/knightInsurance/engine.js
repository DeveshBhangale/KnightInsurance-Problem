export const FIELD_DEFINITIONS = [
  {
    name: "business_name",
    label: "Business name",
    aliases: ["business name", "named insured", "insured name"],
    type: "string",
  },
  {
    name: "requested_effective_date",
    label: "Requested effective date",
    aliases: ["requested effective date", "effective date"],
    type: "date",
  },
  {
    name: "garaging_state",
    label: "Garaging state",
    aliases: ["garaging state", "garaging location state"],
    type: "state",
  },
  {
    name: "operations_description",
    label: "Operations description",
    aliases: ["operations description", "operations"],
    type: "string",
  },
  {
    name: "declared_vehicle_count",
    label: "Declared vehicle count",
    aliases: ["declared vehicle count", "number of vehicles", "vehicle count"],
    type: "integer",
  },
  {
    name: "operating_radius_miles",
    label: "Operating radius miles",
    aliases: ["operating radius miles", "operating radius", "radius miles"],
    type: "number",
  },
  {
    name: "hazardous_materials",
    label: "Hazardous materials",
    aliases: ["hazardous materials", "hazmat"],
    type: "boolean",
  },
  {
    name: "schedule_vehicle_count",
    label: "Vehicle schedule count",
    aliases: [],
    type: "integer",
  },
  {
    name: "loss_runs_present",
    label: "Loss runs attachment",
    aliases: [],
    type: "boolean",
  },
];

const STATE_CODES = new Map(Object.entries({
  Alabama: "AL", Alaska: "AK", Arizona: "AZ", Arkansas: "AR", California: "CA",
  Colorado: "CO", Connecticut: "CT", Delaware: "DE", Florida: "FL", Georgia: "GA",
  Hawaii: "HI", Idaho: "ID", Illinois: "IL", Indiana: "IN", Iowa: "IA", Kansas: "KS",
  Kentucky: "KY", Louisiana: "LA", Maine: "ME", Maryland: "MD", Massachusetts: "MA",
  Michigan: "MI", Minnesota: "MN", Mississippi: "MS", Missouri: "MO", Montana: "MT",
  Nebraska: "NE", Nevada: "NV", "New Hampshire": "NH", "New Jersey": "NJ",
  "New Mexico": "NM", "New York": "NY", "North Carolina": "NC", "North Dakota": "ND",
  Ohio: "OH", Oklahoma: "OK", Oregon: "OR", Pennsylvania: "PA", "Rhode Island": "RI",
  "South Carolina": "SC", "South Dakota": "SD", Tennessee: "TN", Texas: "TX",
  Utah: "UT", Vermont: "VT", Virginia: "VA", Washington: "WA",
  "West Virginia": "WV", Wisconsin: "WI", Wyoming: "WY",
}).map(([name, code]) => [name.toLowerCase(), code]));

const LABELS = FIELD_DEFINITIONS
  .filter((field) => field.aliases.length)
  .flatMap((field) => field.aliases.map((alias) => ({ field, alias })))
  .sort((a, b) => b.alias.length - a.alias.length);

function emptyField(definition, state, evidence = []) {
  return { ...definition, value: null, state, evidence, alternatives: [], override: null };
}

export function normalizeFieldValue(fieldName, rawValue) {
  if (typeof rawValue !== "string" && typeof rawValue !== "number" && typeof rawValue !== "boolean") {
    return { value: null, state: "INVALID" };
  }
  const raw = String(rawValue).trim();
  if (!raw || /^(?:not provided|not applicable|n\/?a|none given|unknown|—|-)$/i.test(raw)) {
    return { value: null, state: "MISSING" };
  }

  switch (fieldName) {
    case "business_name":
    case "operations_description":
      return { value: raw, state: "KNOWN" };
    case "requested_effective_date": {
      const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      const us = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      let year;
      let month;
      let day;
      if (iso) [, year, month, day] = iso;
      else if (us) [, month, day, year] = us;
      else return { value: null, state: "INVALID" };
      const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
      if (
        date.getUTCFullYear() !== Number(year)
        || date.getUTCMonth() !== Number(month) - 1
        || date.getUTCDate() !== Number(day)
      ) return { value: null, state: "INVALID" };
      return { value: `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`, state: "KNOWN" };
    }
    case "garaging_state": {
      const upper = raw.toUpperCase();
      if (/^[A-Z]{2}$/.test(upper) && [...STATE_CODES.values()].includes(upper)) {
        return { value: upper, state: "KNOWN" };
      }
      const code = STATE_CODES.get(raw.toLowerCase());
      return code ? { value: code, state: "KNOWN" } : { value: null, state: "INVALID" };
    }
    case "declared_vehicle_count":
    case "schedule_vehicle_count": {
      const count = raw.match(/^(\d+)(?:\s+vehicles?)?$/i);
      if (!count) return { value: null, state: "INVALID" };
      const value = Number(count[1]);
      return Number.isSafeInteger(value)
        ? { value, state: "KNOWN" }
        : { value: null, state: "INVALID" };
    }
    case "operating_radius_miles": {
      const radius = raw.match(/^((?:\d+(?:\.\d+)?|\.\d+))(?:\s+miles?)?$/i);
      if (!radius) return { value: null, state: "INVALID" };
      const value = Number(radius[1]);
      return Number.isFinite(value) && value >= 0
        ? { value, state: "KNOWN" }
        : { value: null, state: "INVALID" };
    }
    case "hazardous_materials":
    case "loss_runs_present": {
      if (typeof rawValue === "boolean") return { value: rawValue, state: "KNOWN" };
      if (/^(?:yes|true)$/i.test(raw)) return { value: true, state: "KNOWN" };
      if (/^(?:no|false)$/i.test(raw)) return { value: false, state: "KNOWN" };
      return { value: null, state: "INVALID" };
    }
    default:
      return { value: null, state: "INVALID" };
  }
}

function comparisonValue(fieldName, value) {
  if (fieldName === "business_name") return String(value).toLocaleLowerCase().replace(/\s+/g, " ").trim();
  if (fieldName === "operations_description") return String(value).replace(/\s+/g, " ").trim().replace(/[.!?]+$/, "");
  if (fieldName === "operating_radius_miles") return Number(value).toString();
  return String(value);
}

function locatorAt(source, startIndex) {
  if (source.pages?.length) {
    const page = source.pages.find((item) => startIndex >= item.start && startIndex <= item.end);
    return page ? `PDF page ${page.page}` : "PDF text";
  }
  return source.type === "email" ? "email body" : source.type === "csv" ? "CSV text" : "document text";
}

function mentionValues(source, field) {
  const mentions = [];
  const lines = source.text.split(/\r?\n/);
  let offset = 0;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      offset += line.length + 1;
      continue;
    }
    for (const { field: matchedField, alias } of LABELS) {
      if (matchedField.name !== field.name) continue;
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
      const match = trimmed.match(new RegExp(`^\\s*${escaped}\\s*(?::|[–—]|\\s)\\s*(.*?)\\s*$`, "i"));
      if (!match) continue;
      const normalized = normalizeFieldValue(field.name, match[1]);
      mentions.push({
        raw: match[1].trim(),
        ...normalized,
        evidence: {
          source_file: source.name,
          locator: locatorAt(source, offset),
          excerpt_or_observation: trimmed,
        },
      });
      break;
    }
    offset += line.length + 1;
  }
  return mentions;
}

function collectField(field, sources) {
  if (field.name === "schedule_vehicle_count" || field.name === "loss_runs_present") {
    return emptyField(field, "MISSING");
  }
  const unreadablePdfs = sources.filter((source) => source.type === "pdf" && !source.readable);
  const evidence = [];
  const observations = [];
  const validValues = [];
  let invalidFound = false;
  for (const source of sources.filter((item) => item.type === "email" || item.type === "pdf")) {
    const mentions = mentionValues(source, field);
    if (!mentions.length) continue;
    for (const mention of mentions) {
      evidence.push(mention.evidence);
      if (mention.state === "MISSING") continue;
      if (mention.state === "INVALID") {
        invalidFound = true;
        observations.push({ raw: mention.raw, state: "INVALID", evidence: mention.evidence });
      } else {
        validValues.push({ value: mention.value, raw: mention.raw, evidence: mention.evidence });
      }
    }
  }

  if (!evidence.length) {
    const inspected = sources.map((source) => source.name);
    if (unreadablePdfs.length) {
      return emptyField(field, "INVALID", unreadablePdfs.map((source) => ({
        source_file: source.name,
        locator: "attachment processing",
        excerpt_or_observation: `PDF could not be read, so ${field.label.toLowerCase()} could not be verified.`,
      })));
    }
    return emptyField(field, "MISSING", [{
      source_file: inspected.join(", ") || "No sources supplied",
      locator: "inspected source set",
      excerpt_or_observation: `No labeled ${field.label.toLowerCase()} value found.`,
    }]);
  }

  const unique = new Map();
  for (const item of validValues) unique.set(comparisonValue(field.name, item.value), item);
  const alternatives = [...unique.values()].map((item) => ({ value: item.value, raw: item.raw, evidence: item.evidence }));
  if (unique.size > 1) {
    return {
      ...field,
      value: null,
      state: "CONFLICT",
      evidence,
      alternatives,
      override: null,
    };
  }
  if (unreadablePdfs.length) {
    return {
      ...field,
      value: null,
      state: "INVALID",
      evidence: [
        ...evidence,
        ...unreadablePdfs.map((source) => ({
          source_file: source.name,
          locator: "attachment processing",
          excerpt_or_observation: `PDF could not be read to verify whether ${field.label.toLowerCase()} conflicts.`,
        })),
      ],
      alternatives,
      override: null,
    };
  }
  if (invalidFound || !validValues.length) {
    return {
      ...field,
      value: null,
      state: invalidFound ? "INVALID" : "MISSING",
      evidence,
      alternatives: observations,
      override: null,
    };
  }
  return {
    ...field,
    value: validValues[0].value,
    state: "KNOWN",
    evidence,
    alternatives: [],
    override: null,
  };
}

function parseCsvRecords(text) {
  const records = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (quoted) {
      if (character === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        cell += character;
      }
    } else if (character === '"' && cell.length === 0) {
      quoted = true;
    } else if (character === ",") {
      row.push(cell);
      cell = "";
    } else if (character === "\n") {
      row.push(cell.replace(/\r$/, ""));
      if (row.some((value) => value.trim())) records.push(row);
      row = [];
      cell = "";
    } else {
      cell += character;
    }
  }
  row.push(cell.replace(/\r$/, ""));
  if (row.some((value) => value.trim())) records.push(row);
  if (quoted) throw new Error("CSV has an unclosed quoted field.");
  return records;
}

export function countVehicleSchedule(source) {
  try {
    const records = parseCsvRecords(source.text);
    const header = records[0]?.map((value) => value.trim().toLowerCase());
    if (!header || header.join(",") !== "vehicle_id,vin,year,make,model") {
      return { value: null, state: "INVALID", evidence: [{
        source_file: source.name,
        locator: "CSV header",
        excerpt_or_observation: "CSV header is missing or does not match vehicle_id,vin,year,make,model.",
      }] };
    }
    const count = records.slice(1).filter((record) => record.some((value) => value.trim())).length;
    return { value: count, state: "KNOWN", evidence: [{
      source_file: source.name,
      locator: count ? `CSV data rows 1-${count} (header excluded)` : "CSV data rows none (header excluded)",
      excerpt_or_observation: `${count} nonblank vehicle record(s) counted after the header.`,
    }] };
  } catch (error) {
    return { value: null, state: "INVALID", evidence: [{
      source_file: source.name,
      locator: "CSV parse",
      excerpt_or_observation: `Could not parse vehicle schedule: ${error.message}`,
    }] };
  }
}

function isPotentialLossRuns(source) {
  return /loss[\s_-]*(?:runs?|history)|claims[\s_-]*(?:runs?|history)/i.test(source.name)
    || /\b(?:loss runs report|loss history report|claims history report)\b/i.test(source.text);
}

function isKnownNonLossDocument(source) {
  return /application|vehicle[\s_-]*schedule/i.test(source.name)
    || /\bcommercial auto application\b/i.test(source.text);
}

export function deriveLossRuns(sources) {
  const attachments = sources.filter((source) => source.type !== "email");
  const documents = attachments.filter((source) => source.type === "pdf" || source.type === "text");
  const candidates = documents.filter(isPotentialLossRuns);
  const readableReports = candidates.filter((source) => source.readable && source.text.trim());
  if (readableReports.length) {
    return {
      value: true,
      state: "KNOWN",
      evidence: readableReports.map((source) => ({
        source_file: source.name,
        locator: source.pages?.length ? `PDF page 1-${source.pages.length}` : "document text",
        excerpt_or_observation: "Readable supplied attachment identified as a loss runs / loss history report.",
      })),
    };
  }
  const unclassified = documents.filter((source) =>
    !isPotentialLossRuns(source) && !isKnownNonLossDocument(source),
  );
  const unreadable = documents.filter((source) => !source.readable);
  if (candidates.length || unclassified.length || unreadable.length) {
    return {
      value: null,
      state: "INVALID",
      evidence: [...new Set([...candidates, ...unclassified, ...unreadable])].map((source) => ({
        source_file: source.name,
        locator: source.readable ? "document classification" : "attachment inventory",
        excerpt_or_observation: source.readable
          ? isPotentialLossRuns(source)
            ? "Potential loss report supplied, but its document type is unclassifiable."
            : "Supplied document type cannot be determined; loss-report status is unresolved."
          : "Supplied document is unreadable; its type cannot be determined.",
      })),
    };
  }
  return {
    value: false,
    state: "KNOWN",
    evidence: [{
      source_file: attachments.map((source) => source.name).join(", ") || "No attachments",
      locator: "uploaded attachment inventory",
      excerpt_or_observation: "No supplied readable document is identified as a loss runs or loss history report.",
    }],
  };
}

export function extractDeterministic(sources) {
  const fields = FIELD_DEFINITIONS.map((field) => collectField(field, sources));
  const csvSources = sources.filter((source) => source.type === "csv");
  const scheduleField = fields.find((field) => field.name === "schedule_vehicle_count");
  if (!csvSources.length) {
    scheduleField.evidence = [{
      source_file: sources.map((source) => source.name).join(", ") || "No sources supplied",
      locator: "inspected attachment set",
      excerpt_or_observation: "No vehicle schedule CSV supplied.",
    }];
  } else if (csvSources.length > 1) {
    scheduleField.state = "INVALID";
    scheduleField.evidence = csvSources.map((source) => ({
      source_file: source.name,
      locator: "attachment inventory",
      excerpt_or_observation: "More than one vehicle CSV was supplied; schedule count is unresolved.",
    }));
  } else {
    Object.assign(scheduleField, countVehicleSchedule(csvSources[0]));
  }
  Object.assign(fields.find((field) => field.name === "loss_runs_present"), deriveLossRuns(sources));
  return fields;
}

function fieldStatus(fields, fieldName) {
  return fields.find((field) => field.name === fieldName)?.state ?? "MISSING";
}

function fieldValue(fields, fieldName) {
  return fields.find((field) => field.name === fieldName)?.value ?? null;
}

export function evaluateRules(fields) {
  const nameState = fieldStatus(fields, "business_name");
  const dateState = fieldStatus(fields, "requested_effective_date");
  const requiredMissing = nameState === "MISSING" || dateState === "MISSING";
  const requiredUnresolved = ["INVALID", "CONFLICT"].includes(nameState) || ["INVALID", "CONFLICT"].includes(dateState);

  const declaredState = fieldStatus(fields, "declared_vehicle_count");
  const scheduleState = fieldStatus(fields, "schedule_vehicle_count");
  const countUnresolved = declaredState !== "KNOWN" || scheduleState !== "KNOWN";
  const declaredCount = fieldValue(fields, "declared_vehicle_count");
  const scheduleCount = fieldValue(fields, "schedule_vehicle_count");

  const radiusState = fieldStatus(fields, "operating_radius_miles");
  const radius = fieldValue(fields, "operating_radius_miles");
  const hazmatState = fieldStatus(fields, "hazardous_materials");
  const hazmat = fieldValue(fields, "hazardous_materials");
  const lossState = fieldStatus(fields, "loss_runs_present");
  const lossPresent = fieldValue(fields, "loss_runs_present");

  return [
    {
      id: "R1",
      name: "Required identity and effective date",
      status: requiredMissing ? "FLAG" : requiredUnresolved ? "UNKNOWN" : "PASS",
      reason: requiredMissing
        ? `Missing required field${nameState === "MISSING" && dateState === "MISSING" ? "s" : ""}: ${[
          nameState === "MISSING" && "business name",
          dateState === "MISSING" && "requested effective date",
        ].filter(Boolean).join(", ")}.`
        : requiredUnresolved
          ? "Required values are present but invalid or conflicting; resolve the cited evidence."
          : "Business name and valid requested effective date are present without conflicts.",
      values: { business_name: fieldValue(fields, "business_name"), requested_effective_date: fieldValue(fields, "requested_effective_date") },
    },
    {
      id: "R2",
      name: "Vehicle count reconciliation",
      status: countUnresolved ? "UNKNOWN" : declaredCount === scheduleCount ? "PASS" : "FLAG",
      reason: countUnresolved
        ? "Declared count or vehicle schedule count is missing, invalid, conflicting, or unreadable."
        : declaredCount === scheduleCount
          ? "Declared vehicle count matches the nonblank vehicle records in the CSV."
          : "Declared vehicle count does not match the number of nonblank vehicle records in the CSV.",
      values: { declared_vehicle_count: declaredCount, schedule_vehicle_count: scheduleCount },
    },
    {
      id: "R3",
      name: "Operating radius",
      status: radiusState !== "KNOWN" ? "UNKNOWN" : radius > 150 ? "FLAG" : "PASS",
      reason: radiusState !== "KNOWN"
        ? "Radius is absent, invalid, or conflicting."
        : radius > 150
          ? "Operating radius exceeds the 150-mile threshold."
          : "Operating radius is at or below 150 miles; 150 miles is allowed.",
      values: { operating_radius_miles: radius, threshold_miles: 150 },
    },
    {
      id: "R4",
      name: "Hazardous materials",
      status: hazmatState !== "KNOWN" || typeof hazmat !== "boolean" ? "UNKNOWN" : hazmat ? "FLAG" : "PASS",
      reason: hazmatState !== "KNOWN" || typeof hazmat !== "boolean"
        ? "Hazardous-materials answer is missing, ambiguous, invalid, or conflicting."
        : hazmat
          ? "Applicant explicitly answered Yes for hazardous materials."
          : "Applicant explicitly answered No for hazardous materials.",
      values: { hazardous_materials: hazmat },
    },
    {
      id: "R5",
      name: "Loss runs attachment",
      status: lossState !== "KNOWN" || typeof lossPresent !== "boolean" ? "UNKNOWN" : lossPresent ? "PASS" : "FLAG",
      reason: lossState !== "KNOWN" || typeof lossPresent !== "boolean"
        ? "A potential loss report was attached but could not be read or classified."
        : lossPresent
          ? "A supplied readable attachment is explicitly identified as a loss runs or loss history report."
          : "No loss runs/history report is attached; an email promise does not count.",
      values: { loss_runs_present: lossPresent },
    },
  ];
}

export function overallStatus(rules) {
  return rules.every((rule) => rule.status === "PASS") ? "READY_FOR_REVIEW" : "NEEDS_REVIEW";
}

export function mergeAiFieldEvidence(fields, aiFields, sources) {
  const sourceMap = new Map(sources.map((source) => [source.name, source]));
  return fields.map((field) => {
    if (!field.aliases.length) return field;
    const candidate = aiFields?.[field.name];
    if (!candidate || !Array.isArray(candidate.evidence)) return field;
    const accepted = [];
    for (const citation of candidate.evidence) {
      if (!citation || typeof citation.source_file !== "string" || typeof citation.excerpt !== "string") continue;
      const source = sourceMap.get(citation.source_file);
      if (!source?.readable || !citation.excerpt.trim()) continue;
      const excerpt = citation.excerpt.trim();
      const normalizedExcerpt = excerpt.replace(/\s+/g, " ").toLocaleLowerCase();
      let verifiedLocator = citation.locator;
      if (source.pages?.length) {
        const pageNumber = String(citation.locator ?? "").match(/(?:pdf\s*)?page\s*(\d+)/i)?.[1];
        const citedPage = source.pages.find((page) => String(page.page) === pageNumber);
        if (!citedPage) continue;
        const pageText = source.text.slice(citedPage.start, citedPage.end).replace(/\s+/g, " ").toLocaleLowerCase();
        if (!pageText.includes(normalizedExcerpt)) continue;
        verifiedLocator = `PDF page ${citedPage.page}`;
      } else {
        const sourceText = source.text.replace(/\s+/g, " ").toLocaleLowerCase();
        if (!sourceText.includes(normalizedExcerpt)) continue;
        if (source.type === "email") verifiedLocator = "email body";
      }
      const excerptSource = { ...source, text: excerpt, pages: [] };
      const extracted = mentionValues(excerptSource, field);
      const matching = extracted.find((item) => {
        if (item.state !== "KNOWN") return false;
        const aiNormalized = normalizeFieldValue(field.name, String(candidate.value ?? ""));
        return aiNormalized.state === "KNOWN"
          && comparisonValue(field.name, item.value) === comparisonValue(field.name, aiNormalized.value);
      });
      if (!matching) continue;
      accepted.push({
        value: matching.value,
        raw: matching.raw,
        evidence: {
          source_file: source.name,
          locator: typeof verifiedLocator === "string" ? verifiedLocator : matching.evidence.locator,
          excerpt_or_observation: excerpt,
          verified_ai: true,
        },
      });
    }
    if (!accepted.length) return field;
    const combined = [
      ...field.evidence.map((evidence) => {
      const mention = mentionValues(sourceMap.get(evidence.source_file) ?? { name: evidence.source_file, type: "text", text: evidence.excerpt_or_observation, readable: true }, field).find((item) => item.state === "KNOWN");
        return mention ? { ...mention, evidence } : null;
      }).filter(Boolean),
      ...accepted,
    ].filter((item) => item.state === "KNOWN");
    const unique = new Map(combined.map((item) => [
      comparisonValue(field.name, item.value),
      item,
    ]));
    const alternatives = [...unique.values()];
    const evidence = [...field.evidence, ...accepted.map((item) => item.evidence)];
    if (unique.size > 1) {
      return { ...field, value: null, state: "CONFLICT", evidence, alternatives, override: null };
    }
    if (field.state === "CONFLICT" || field.state === "INVALID") return { ...field, evidence, override: null };
    return { ...field, value: alternatives[0].value, state: "KNOWN", evidence, alternatives: [], override: null };
  });
}

export function applyHumanOverride(fields, fieldName, rawValue) {
  return fields.map((field) => {
    if (field.name !== fieldName) return field;
    const normalized = normalizeFieldValue(fieldName, rawValue);
    return {
      ...field,
      value: normalized.value,
      state: normalized.state === "MISSING" ? "MISSING" : normalized.state === "INVALID" ? "INVALID" : "KNOWN",
      override: {
        value: normalized.value,
        state: normalized.state === "MISSING" ? "MISSING" : normalized.state === "INVALID" ? "INVALID" : "KNOWN",
        raw: String(rawValue),
      },
      evidence: field.evidence,
    };
  });
}

export function buildDeterministicNarrative(fields, rules, submissionId = "Submission") {
  const get = (name) => fieldValue(fields, name);
  const operations = get("operations_description")?.replace(/[.!?]+$/, "");
  const ruleLines = rules.map((rule) => `${rule.id} ${rule.name}: ${rule.status} — ${rule.reason}`);
  return [
    `${submissionId} underwriting triage.`,
    `Business: ${get("business_name") ?? "not provided"}. Effective date: ${get("requested_effective_date") ?? "not provided"}.`,
    `Garaging state: ${get("garaging_state") ?? "not provided"}. Operations: ${operations ?? "not provided"}.`,
    `Declared vehicles: ${get("declared_vehicle_count") ?? "not provided"}; schedule rows: ${get("schedule_vehicle_count") ?? "not available"}.`,
    `Operating radius: ${get("operating_radius_miles") === null ? "not provided" : `${get("operating_radius_miles")} miles`}. Hazardous materials: ${get("hazardous_materials") === null ? "not provided" : get("hazardous_materials") ? "Yes" : "No"}.`,
    `Loss runs attachment: ${get("loss_runs_present") === null ? "unresolved" : get("loss_runs_present") ? "present" : "not present"}.`,
    ...ruleLines,
    `Overall status: ${overallStatus(rules)}. This is readiness for human review only, not a coverage or binding decision.`,
  ].join("\n");
}

export function buildFallbackFollowUp(fields, rules, submissionId = "Submission") {
  const missing = fields.filter((field) => field.state === "MISSING");
  const invalid = fields.filter((field) => field.state === "INVALID");
  const conflicts = fields.filter((field) => field.state === "CONFLICT");
  const flagged = rules.filter((rule) => rule.status === "FLAG");
  const lines = [
    "Hello,",
    "",
    `Regarding ${submissionId}, could you please provide or confirm the following information so we can complete our review?`,
  ];
  for (const field of missing) {
    if (field.name === "loss_runs_present" || field.name === "schedule_vehicle_count") continue;
    lines.push(`- ${field.label}.`);
  }
  for (const field of invalid) {
    if (field.name === "loss_runs_present" || field.name === "schedule_vehicle_count") continue;
    lines.push(`- Please confirm a valid ${field.label.toLowerCase()}; the supplied value could not be used.`);
  }
  for (const field of conflicts) {
    lines.push(`- ${field.label}: our documents show ${field.alternatives.map((item) => item.raw ?? item.value).join(" / ")}. Which value is correct?`);
  }
  for (const rule of flagged) {
    if (rule.id === "R2") lines.push("- Please reconcile the declared vehicle count with the vehicle schedule.");
    if (rule.id === "R3") lines.push("- Please confirm the operating radius and advise whether the stated radius is accurate.");
    if (rule.id === "R4") lines.push("- Please clarify the hazardous-materials exposure and provide details.");
  }
  const schedule = fields.find((field) => field.name === "schedule_vehicle_count");
  if (schedule?.state === "MISSING" || schedule?.state === "INVALID") {
    lines.push("- Please provide a readable vehicle schedule CSV so the listed vehicles can be counted.");
  }
  const loss = fields.find((field) => field.name === "loss_runs_present");
  if (loss?.value === false || loss?.state === "INVALID") {
    lines.push("- Please provide a readable loss runs / loss history report, if available.");
  }
  if (lines.length === 3) lines.push("- Please let us know if any submission information has changed.");
  lines.push("", "Thank you,", "[Underwriter name]");
  return lines.join("\n");
}

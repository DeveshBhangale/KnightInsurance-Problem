import test from "node:test";
import assert from "node:assert/strict";
import {
  applyHumanOverride,
  countVehicleSchedule,
  evaluateRules,
  extractDeterministic,
  mergeAiFieldEvidence,
  normalizeFieldValue,
  overallStatus,
} from "../engine.js";

const email = (body) => ({ name: "broker_email.txt", type: "email", text: body, readable: true });
const pdf = (name, text, readable = true) => ({ name, type: "pdf", text, pages: [{ page: 1, start: 0, end: text.length }], readable });
const csv = (text) => ({ name: "vehicles.csv", type: "csv", text, readable: true });
const appText = `Commercial auto application
Business name Acme Delivery LLC
Requested effective date 2026-11-01
Garaging state California
Operations description Local delivery of packages
Declared vehicle count 2
Operating radius miles 100
Hazardous materials No`;
const goodCsv = `vehicle_id,vin,year,make,model
V-01,FICTIONAL001,2023,Example,Van
V-02,FICTIONAL002,2024,Example,Van`;

function process(sources) {
  return evaluateRules(extractDeterministic(sources));
}

function status(rules, id) {
  return rules.find((rule) => rule.id === id)?.status;
}

test("normalizes identity, dates, California, numeric thresholds and explicit yes/no", () => {
  assert.deepEqual(normalizeFieldValue("requested_effective_date", "2026-11-01"), { value: "2026-11-01", state: "KNOWN" });
  assert.deepEqual(normalizeFieldValue("requested_effective_date", "2026-02-30"), { value: null, state: "INVALID" });
  assert.deepEqual(normalizeFieldValue("garaging_state", "California"), { value: "CA", state: "KNOWN" });
  assert.deepEqual(normalizeFieldValue("operating_radius_miles", "150 miles"), { value: 150, state: "KNOWN" });
  assert.deepEqual(normalizeFieldValue("declared_vehicle_count", "0 vehicles"), { value: 0, state: "KNOWN" });
  assert.deepEqual(normalizeFieldValue("hazardous_materials", "No"), { value: false, state: "KNOWN" });
  assert.deepEqual(normalizeFieldValue("hazardous_materials", "maybe"), { value: null, state: "INVALID" });
});

test("R1 passes required normalized values and missing fields take precedence", () => {
  const good = process([email("Business name ACME Delivery LLC\nRequested effective date 2026-11-01")]);
  assert.equal(status(good, "R1"), "PASS");
  const missingAndConflict = process([
    email("Business name Acme LLC\nBusiness name Other LLC"),
    pdf("application.pdf", "Commercial auto application\nBusiness name Acme LLC\nBusiness name Other LLC"),
  ]);
  assert.equal(status(missingAndConflict, "R1"), "FLAG");
  const conflict = process([
    email("Business name Acme LLC\nRequested effective date 2026-11-01"),
    pdf("application.pdf", "Commercial auto application\nBusiness name Other LLC\nRequested effective date 2026-11-01"),
  ]);
  assert.equal(status(conflict, "R1"), "UNKNOWN");
  const invalid = process([email("Business name Acme LLC\nRequested effective date 2026-02-30")]);
  assert.equal(status(invalid, "R1"), "UNKNOWN");
  const missingAndInvalid = process([email("Requested effective date 2026-02-30")]);
  assert.equal(status(missingAndInvalid, "R1"), "FLAG");
});

test("R2 counts nonblank CSV data rows, excludes the header and allows zero vehicles", () => {
  assert.deepEqual(countVehicleSchedule(csv(`${goodCsv}\n\n`)).value, 2);
  assert.equal(countVehicleSchedule(csv("vehicle_id,vin,year,make,model")).value, 0);
  assert.equal(status(process([email(appText), csv(goodCsv)]), "R2"), "PASS");
  assert.equal(status(process([
    email(appText.replace("vehicle count 2", "vehicle count 0")),
    csv("vehicle_id,vin,year,make,model"),
  ]), "R2"), "PASS");
  const unequal = process([email(appText.replace("vehicle count 2", "vehicle count 3")), csv(goodCsv)]);
  assert.equal(status(unequal, "R2"), "FLAG");
});

test("R2 returns UNKNOWN for a missing, conflicting, invalid, or malformed schedule", () => {
  assert.equal(status(process([email(appText)]), "R2"), "UNKNOWN");
  const conflict = process([
    email(appText),
    pdf("application.pdf", `${appText}\nDeclared vehicle count 3`),
    csv(goodCsv),
  ]);
  assert.equal(status(conflict, "R2"), "UNKNOWN");
  assert.equal(status(process([email(appText.replace("vehicle count 2", "vehicle count two")), csv(goodCsv)]), "R2"), "UNKNOWN");
  assert.equal(status(process([email(appText), csv("not,a,vehicle,schedule\nV1")]), "R2"), "UNKNOWN");
});

test("R3 permits 150 and 150.0 but flags a value above 150", () => {
  for (const radius of ["150", "150.0"]) {
    const rules = process([email(appText.replace("radius miles 100", `radius miles ${radius}`)), csv(goodCsv)]);
    assert.equal(status(rules, "R3"), "PASS");
  }
  assert.equal(status(process([email(appText.replace("radius miles 100", "radius miles 150.1")), csv(goodCsv)]), "R3"), "FLAG");
});

test("R3 returns UNKNOWN for missing, negative, nonnumeric, and conflicting radii", () => {
  for (const value of ["Not provided", "-1", "far"]) {
    const sources = [email(appText.replace("radius miles 100", `radius miles ${value}`)), csv(goodCsv)];
    assert.equal(status(process(sources), "R3"), "UNKNOWN");
    if (value === "Not provided") {
      const radius = extractDeterministic(sources).find((field) => field.name === "operating_radius_miles");
      assert.equal(radius.state, "MISSING");
      assert.match(radius.evidence[0].excerpt_or_observation, /Not provided/);
    }
  }
  const conflict = process([
    email(appText),
    pdf("application.pdf", `${appText}\nOperating radius miles 90`),
    csv(goodCsv),
  ]);
  assert.equal(status(conflict, "R3"), "UNKNOWN");
});

test("R4 passes explicit No, flags Yes, and returns UNKNOWN for absent/ambiguous/conflicting", () => {
  assert.equal(status(process([email(appText), csv(goodCsv)]), "R4"), "PASS");
  assert.equal(status(process([email(appText.replace("materials No", "materials Yes")), csv(goodCsv)]), "R4"), "FLAG");
  for (const value of ["Not provided", "Maybe"]) {
    assert.equal(status(process([email(appText.replace("materials No", `materials ${value}`)), csv(goodCsv)]), "R4"), "UNKNOWN");
  }
  const conflict = process([
    email(appText),
    pdf("application.pdf", `${appText}\nHazardous materials Yes`),
    csv(goodCsv),
  ]);
  assert.equal(status(conflict, "R4"), "UNKNOWN");
});

test("R5 depends on actual readable attachment inventory, not broker promises", () => {
  const missingReportSources = [email(`${appText}\nLoss runs will follow`), pdf("application.pdf", appText), csv(goodCsv)];
  assert.equal(status(process(missingReportSources), "R5"), "FLAG");
  const lossField = extractDeterministic(missingReportSources).find((field) => field.name === "loss_runs_present");
  assert.equal(lossField.evidence[0].source_file, "application.pdf, vehicles.csv");
  assert.doesNotMatch(lossField.evidence[0].source_file, /broker_email/);
  assert.equal(status(process([email(appText), pdf("application.pdf", appText), pdf("loss_runs.pdf", "Loss runs report\nReported claims 0"), csv(goodCsv)]), "R5"), "PASS");
  assert.equal(status(process([email(appText), pdf("application.pdf", appText), pdf("loss_runs.pdf", "", false), csv(goodCsv)]), "R5"), "UNKNOWN");
  assert.equal(status(process([email(appText), pdf("application.pdf", appText), pdf("unknown.pdf", "Unreadable unrelated document type is not identifiable"), csv(goodCsv)]), "R5"), "UNKNOWN");
});

test("field conflict preserves alternatives, evidence, and null effective value", () => {
  const fields = extractDeterministic([
    email("Business name Acme Delivery LLC\nRequested effective date 2026-11-01"),
    pdf("application.pdf", "Commercial auto application\nBusiness name Other Delivery LLC\nRequested effective date 2026-11-01"),
  ]);
  const name = fields.find((field) => field.name === "business_name");
  assert.equal(name.state, "CONFLICT");
  assert.equal(name.value, null);
  assert.equal(name.alternatives.length, 2);
  assert.equal(name.evidence[0].source_file, "broker_email.txt");
  assert.equal(name.evidence[1].locator, "PDF page 1");
});

test("CSV evidence identifies header exclusion and observed count", () => {
  const field = extractDeterministic([email(appText), csv(goodCsv)]).find((item) => item.name === "schedule_vehicle_count");
  assert.equal(field.value, 2);
  assert.match(field.evidence[0].locator, /header excluded/);
  assert.match(field.evidence[0].excerpt_or_observation, /2 nonblank/);
});

test("manual correction is explicitly labeled and preserves original evidence", () => {
  const fields = extractDeterministic([email("Business name Acme LLC\nRequested effective date 2026-11-01")]);
  const corrected = applyHumanOverride(fields, "business_name", "Acme Holdings LLC");
  const name = corrected.find((field) => field.name === "business_name");
  assert.equal(name.value, "Acme Holdings LLC");
  assert.equal(name.override.raw, "Acme Holdings LLC");
  assert.equal(name.evidence[0].excerpt_or_observation, "Business name Acme LLC");
});

test("human correction resolves a source conflict for subsequent deterministic checks", () => {
  const sources = [
    email("Business name Acme LLC\nRequested effective date 2026-11-01\nOperating radius miles 180"),
    pdf("application.pdf", "Commercial auto application\nBusiness name Acme LLC\nRequested effective date 2026-11-01\nOperating radius miles 80"),
    csv(goodCsv),
  ];
  const extracted = extractDeterministic(sources);
  assert.equal(extracted.find((field) => field.name === "operating_radius_miles").state, "CONFLICT");
  const corrected = applyHumanOverride(extracted, "operating_radius_miles", "80");
  assert.equal(corrected.find((field) => field.name === "operating_radius_miles").state, "KNOWN");
  assert.equal(corrected.find((field) => field.name === "operating_radius_miles").override.raw, "80");
  assert.equal(evaluateRules(corrected).find((rule) => rule.id === "R3").status, "PASS");
  assert.equal(corrected.find((field) => field.name === "operating_radius_miles").evidence.length, 2);
});

test("AI extraction is accepted only with verifiable field evidence and locators", () => {
  const sources = [
    email("Business name Acme LLC\nRequested effective date 2026-11-01"),
    pdf("application.pdf", "Commercial auto application\nBusiness name Acme LLC\nRequested effective date 2026-11-01"),
  ];
  const base = extractDeterministic(sources);
  const validAi = {
    business_name: {
      value: "Acme LLC",
      evidence: [{ source_file: "application.pdf", locator: "PDF page 1", excerpt: "Business name Acme LLC" }],
    },
  };
  const accepted = mergeAiFieldEvidence(base, validAi, sources).find((field) => field.name === "business_name");
  assert.equal(accepted.value, "Acme LLC");
  assert.ok(accepted.evidence.some((evidence) => evidence.locator === "PDF page 1"));

  const fabricated = {
    business_name: {
      value: "Fabricated LLC",
      evidence: [{ source_file: "application.pdf", locator: "PDF page 1", excerpt: "Business name Fabricated LLC" }],
    },
  };
  const rejected = mergeAiFieldEvidence(base, fabricated, sources).find((field) => field.name === "business_name");
  assert.equal(rejected.value, "Acme LLC");
  assert.equal(rejected.state, "KNOWN");

  const wrongPage = {
    business_name: {
      value: "Other LLC",
      evidence: [{ source_file: "application.pdf", locator: "PDF page 2", excerpt: "Business name Acme LLC" }],
    },
  };
  const rejectedPage = mergeAiFieldEvidence(base, wrongPage, sources).find((field) => field.name === "business_name");
  assert.equal(rejectedPage.value, "Acme LLC");
});

test("overall result is READY only when every exact supplied rule passes", () => {
  const allPass = process([
    email(appText),
    pdf("application.pdf", appText),
    csv(goodCsv),
    pdf("loss_runs.pdf", "Loss runs report\nReported claims 0"),
  ]);
  assert.deepEqual(allPass.map((rule) => rule.status), ["PASS", "PASS", "PASS", "PASS", "PASS"]);
  assert.equal(overallStatus(allPass), "READY_FOR_REVIEW");
  assert.equal(overallStatus(process([email(appText), csv(goodCsv)])), "NEEDS_REVIEW");
});

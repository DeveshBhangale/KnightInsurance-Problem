# Submission Desk — commercial auto candidate exercise

A local browser application for reviewing the supplied fictional commercial auto packets. It reads broker email, selectable-text PDF attachments and CSV vehicle schedules; extracts the exact shared fields with evidence; applies R1–R5 deterministically; and displays a source-grounded model summary and editable broker follow-up draft. A reviewer can correct fields, retain their original evidence, label human overrides, and rerun all five rules.

The interface uses the Knight Insurance Group logo image published on the [official company website](https://www.knightinsurancegroup.com/) and its published blue brand color. The logo is loaded from the company's own media host rather than recreated or bundled. The responsive landing section and underwriting workbench are a candidate concept, not an official company product or an endorsement by Knight Insurance Group.

## Run locally

Requirements: Python 3.9+ for a static HTTP server. Node.js 18+ is needed only to run the tests; no Node runtime, build process, API key, or server-side application is required to use the browser app.

```sh
python3 -m http.server 8000
```

Open <http://127.0.0.1:8000/>. Keep the project root as the server directory so PDF.js, the sample packets, and their PDFs are available at their expected relative paths. The initial view is empty. Choose SUB-A, SUB-B, or SUB-C from **Load candidate packet** to load a complete supplied packet; alternatively paste a broker email, add attachments, and choose **Process submission**.

The application includes the supplied fictional materials under `candidate_materials/`. PDF.js 4.10.38 is bundled locally in `vendor/pdfjs/`, including its Mozilla license, and extracts selectable PDF text in the browser. Scanned documents/OCR are outside the assignment.

## AI model setup

The app makes an actual OpenAI-compatible `/chat/completions` request for extraction and a narrative summary plus draft email. Expand **AI model connection**, enter the endpoint base URL and model name, and optionally provide a bearer token. Example for a local Ollama-compatible server:

- API base URL: `http://localhost:11434/v1`
- Model name: the model installed in your local provider
- API key: blank for a local provider, if it does not require one

The endpoint must permit requests from the local app origin (CORS). A remote provider receives packet text; use only the supplied fictional exercise data. The optional API token remains in the current page's memory only and is never written to local storage or source files.

**AI integration limitation:** The application contains the real model-call path, strict JSON parsing, a prompt treating document contents as untrusted data, source/excerpt/page citation verification, and explicit unconfigured/error states. There was no Ollama/LM Studio runtime or provider credential available in the build environment, so no live model call was made during development or verification. Until a provider is configured, the app shows deterministic extraction/rules and labels its narrative as a deterministic fallback—not as AI output. This is incomplete relative to the instruction to demonstrate a successful real-model call.

**AI coding tool disclosure:** Implemented with an AI assistant using Copilot SDK in VS Code. No live LLM provider/model was used to process the submissions during verification.

## Field and evidence behavior

The shared contract fields are `business_name`, `requested_effective_date`, `garaging_state`, `operations_description`, `declared_vehicle_count`, `operating_radius_miles`, `hazardous_materials`, `loss_runs_present`, and derived `schedule_vehicle_count`.

- Email and PDF labels are extracted deterministically first. Dates are calendar-validated and normalized to `YYYY-MM-DD`; full state names (including California) become postal codes; booleans require explicit Yes/No; count and radius values are typed.
- When explicit normalized values conflict across sources, the effective value is `null`, state is `CONFLICT`, and alternatives and citations remain visible. A vehicle count from a schedule is kept separate from the broker-declared count.
- Each value includes source filename, email body/PDF page/CSV data-row locator, and a quote or counted-row observation. Missing fields list the inspected sources; absent loss reports show the uploaded attachment inventory.
- AI-proposed extraction is merged only when its cited excerpt exists in the exact named source, its PDF page locator exists, and the cited field label/value normalize consistently. Failed/uncited model values are not accepted.
- PDF parse failures are visible; affected extractions stay unresolved. Multiple vehicle CSV files are treated as an unresolved schedule rather than guessed/aggregated.

## Supplied rule implementation

All rule decisions are ordinary code in `engine.js`; the model cannot set statuses:

| Rule | PASS | FLAG | UNKNOWN |
|---|---|---|---|
| R1 Required identity/date | Business name and valid effective date are present and non-conflicting | A required field is missing; missing takes precedence | No required field is missing, but at least one is invalid or conflicting |
| R2 Vehicle count | Valid nonnegative declared and CSV row counts match | Both valid counts exist and differ | Either is absent, invalid, conflicting, or the schedule is unreadable |
| R3 Operating radius | Valid radius ≤150 miles (150.0 is allowed) | Valid radius >150 miles | Missing, invalid/negative, or conflicting |
| R4 Hazardous materials | Explicit non-conflicting No | Explicit non-conflicting Yes | Missing, ambiguous, invalid, or conflicting |
| R5 Loss runs | A supplied readable attachment is explicitly identified as loss runs/history | No loss history report in the actual attachment inventory; an email promise does not count | Potential or unclassified attachment cannot be read/classified |

Overall status is `READY_FOR_REVIEW` only when every rule is PASS; otherwise it is `NEEDS_REVIEW`. Neither status approves, declines, quotes, prices, or binds coverage.

## Sample packet expected results

- **SUB-A:** R1–R5 PASS; overall `READY_FOR_REVIEW`. The readable zero-loss report satisfies attachment presence only.
- **SUB-B:** R1 FLAG, R2 PASS, R3 UNKNOWN, R4 UNKNOWN, R5 FLAG; overall `NEEDS_REVIEW`. The broker's promise to send loss runs is not an attachment.
- **SUB-C:** R1 PASS, R2 FLAG (declared 4 vs. 3 schedule rows), R3 UNKNOWN (180 email vs. 80 application), R4 UNKNOWN (Yes vs. No), R5 FLAG; overall `NEEDS_REVIEW`.

VINs are counted as records only; they are never decoded or validated. No additional fleet-size, date-range, loss-severity, appetite, or eligibility rules are invented.

## Tests

The deterministic tests do not call a live model:

```sh
npm test
```

They cover required-field precedence, missing/invalid/conflicting data, schedule header exclusion and zero rows, count reconciliation, 150/150.0/150.1 radius boundaries, hazardous-materials answers, attachment-based loss report detection, evidence references, human overrides, and overall status.

Browser smoke checks also covered sample packet loading, manual CSV upload, manual PDF-plus-CSV upload, correction/rerun, packet-switch isolation, and an unavailable-model error. Manual uploads show which attachment is being read and surface parse errors rather than silently treating unreadable files as valid.

## Architecture and limitations

- Plain HTML/CSS/JavaScript ES modules. Rules and schema are in `engine.js`; UI, PDF parsing, sample loading and model calls are in `app.js`.
- PDF.js 4.10.38, vendored under `vendor/pdfjs/`; other than the optional user-configured model endpoint, no external services are called.
- Inputs and results stay in the local browser tab; no email is sent, no mailbox is connected, and no applicant data is persisted.
- No scanned-PDF OCR, mailbox integration, authentication, AWS deployment, or coverage decisions.
- Model output can still be narratively wrong; verify it against evidence. The deterministic rule layer remains authoritative.
- The supplied response template asks for the candidate's full name, email, onsite availability/relocation willingness, and timeline. These personal answers were not supplied and must be completed by the candidate rather than invented.

## Deliverables / incomplete items

- Source ZIP: `submission-desk.zip` (includes application source, tests, PDF.js and license, and the supplied fictional candidate materials).
- Demo video: not produced in this environment; demonstrate packet loading, citations, all three rule outcomes, correcting SUB-C's operating radius/hazmat answer and rerunning rules, then switching packets.
- Real-model verification: not completed because no provider/model runtime or credential was available. Configure one before recording the required successful AI extraction and narrative flow.
- Approximate time spent was not independently tracked.
